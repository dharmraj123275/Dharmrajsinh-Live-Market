let selected=null,liveTimer=null;
const $=id=>document.getElementById(id);
const fmt=v=>Number.isFinite(Number(v))?Number(v).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2}):"0.00";
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const metric=(a,b)=>`<div class="metric"><small>${esc(a)}</small><b>${esc(b)}</b></div>`;
const level=(a,b)=>`<div class="level"><small>${esc(a)}</small><b>₹${fmt(b)}</b></div>`;
const tag=(a,b)=>`<div class="tag"><small>${esc(a)}</small><b>${esc(b)}</b></div>`;

async function status(){
 try{const d=await(await fetch("/api/status")).json();$("marketStatus").textContent=d.market;$("lastUpdate").textContent=`${d.date} ${d.time}`}
 catch{$("marketStatus").textContent="STATUS ERROR"}
}
async function indexes(){
 try{
  const d=await(await fetch("/api/market-overview")).json(),x=d.data||{};
  $("indexes").innerHTML=Object.values(x).map(v=>`<div class="index"><b>${esc(v.symbol)}</b><strong>${v.unavailable?"—":"₹"+fmt(v.price)}</strong><div class="${v.netChange>=0?"up":"down"}">${v.unavailable?"Unavailable":(v.netChange>=0?"+":"")+fmt(v.netChange)} (${fmt(v.changePercent)}%)</div><small>${esc(v.name)}</small></div>`).join("");
 }catch(e){$("indexes").innerHTML=`<div class="error" style="grid-column:1/-1">${esc(e.message)}</div>`}
}
async function searchStock(){
 const q=$("search").value.trim(),ex=$("exchange").value;if(!q)return;
 $("searchResults").innerHTML=`<div class="loading">Searching ${esc(q)}...</div>`;
 try{
  const d=await(await fetch(`/api/search?q=${encodeURIComponent(q)}&exchange=${ex}`)).json();if(!d.success)throw Error(d.message);
  window.rows=d.results||[];
  $("searchResults").innerHTML=window.rows.length?`<div class="results">${window.rows.map((x,i)=>`<div class="item"><div><b>${esc(x.symbol)}</b><br><small>${esc(x.name)} • ${esc(x.exchange)}</small></div><button onclick="selectStock(${i})">ANALYZE</button></div>`).join("")}</div>`:`<div class="error">No NSE/BSE result.</div>`;
 }catch(e){$("searchResults").innerHTML=`<div class="error">${esc(e.message)}</div>`}
}
async function selectStock(i){
 selected=window.rows?.[i];if(!selected)return;
 if(liveTimer)clearInterval(liveTimer);await live();liveTimer=setInterval(live,5000);
}
async function live(){
 if(!selected)return;
 $("result").innerHTML=`<div class="loading">📡 Live analysis: ${esc(selected.symbol)}</div>`;
 try{
  const u=`/api/live?instrument=${encodeURIComponent(selected.instrument)}&symbol=${encodeURIComponent(selected.symbol)}&name=${encodeURIComponent(selected.name)}`;
  const d=await(await fetch(u)).json();if(!d.success)throw Error(d.message);render(d.data);
 }catch(e){$("result").innerHTML=`<div class="error">${esc(e.message)}</div>`}
}
function render(d){
 const s=d.signal||"WAIT",cls=s.includes("BUY")?"buy":s.includes("SELL")?"sell":"wait",t=d.technicalConfirmation||{},m=d.marketDepth||{};
 $("result").innerHTML=`<div class="analysis">
 <div class="head"><div><h2>${esc(d.symbol)}</h2><p>${esc(d.name)} • ${esc(d.instrument)}</p></div><div class="signal ${cls}">${esc(s)}<br><small>AI ${fmt(d.aiScore)}/100</small></div></div>
 <div class="price">₹${fmt(d.price)}</div><div class="${d.netChange>=0?"up":"down"}">${d.netChange>=0?"+":""}${fmt(d.netChange)} (${fmt(d.changePercent)}%)</div>
 <div class="metrics">${metric("Previous Close","₹"+fmt(d.prevClose))}${metric("ATP","₹"+fmt(d.avgTradePrice))}${metric("Open","₹"+fmt(d.open))}${metric("High","₹"+fmt(d.high))}${metric("Low","₹"+fmt(d.low))}${metric("Volume",fmt(d.volume))}${metric("OI",fmt(d.oi))}${metric("Confidence",fmt(d.confidence)+"%")}</div>
 <div class="section"><h3>🎯 Trading Setup</h3><div class="levels">${level("Entry",d.entry)}${level("Target 1",d.target1)}${level("Target 2",d.target2)}${level("Stop Loss",d.stopLoss)}${level("Support",d.support)}${level("Resistance",d.resistance)}</div><p class="note">R:R 1 : ${fmt(d.riskReward)} • ${esc(d.tradeQuality)} • ${esc(d.reason)}</p></div>
 <div class="section"><h3>📊 Market Depth</h3><div>Buy ${fmt(m.buyPercent)}% | Sell ${fmt(m.sellPercent)}%</div><div class="bar"><i style="width:${Math.max(0,Math.min(100,m.buyPercent||0))}%"></i></div><div class="metrics">${metric("Buy Qty",fmt(m.buyQuantity))}${metric("Sell Qty",fmt(m.sellQuantity))}${metric("Depth",m.trend)}</div></div>
 <div class="section"><h3>🧠 Technical Confirmation</h3><div class="tech">${tag("Score",(t.technicalScore>0?"+":"")+fmt(t.technicalScore))}${tag("EMA",t.emaTrend)}${tag("VWAP",t.vwapTrend)}${tag("RSI",t.rsiSignal+" • "+fmt(t.rsi14))}${tag("Volume",t.volumeConfirmed?"CONFIRMED":"NORMAL")}${tag("Volume Ratio",fmt(t.volumeRatio)+"x")}${tag("EMA 9","₹"+fmt(t.ema9))}${tag("EMA 21","₹"+fmt(t.ema21))}${tag("ATR 14","₹"+fmt(t.atr14))}</div><p class="note">⚡ ${esc(t.confirmationStatus)}</p></div>
 <div class="section"><h3>📅 Previous Day</h3><div class="metrics">${metric("Open","₹"+fmt(d.previousDay?.open))}${metric("High","₹"+fmt(d.previousDay?.high))}${metric("Low","₹"+fmt(d.previousDay?.low))}${metric("Close","₹"+fmt(d.previousDay?.close))}</div></div>
 <div class="section"><h3>📰 Fundamentals / News</h3><p class="note">V7.4 does not invent fundamentals or news. A separate data provider can be connected later. Live technical, price and market-depth analysis comes from Upstox.</p></div>
 </div>`;
}
$("search")?.addEventListener("keydown",e=>{if(e.key==="Enter")searchStock()});
status();indexes();setInterval(status,15000);setInterval(indexes,5000);
