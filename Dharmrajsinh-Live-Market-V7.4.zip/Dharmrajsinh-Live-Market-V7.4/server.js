const express = require("express");
const cors = require("cors");
const axios = require("axios");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 10000;
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const API = "https://api.upstox.com";
const API3 = "https://api.upstox.com/v3";
let accessToken = process.env.UPSTOX_ACCESS_TOKEN || "";

const INDEXES = {
  NIFTY50: { key: "NSE_INDEX|Nifty 50", symbol: "NIFTY 50", name: "Nifty 50" },
  SENSEX: { key: "BSE_INDEX|SENSEX", symbol: "SENSEX", name: "Sensex" },
  MIDCPNIFTY: { key: "NSE_INDEX|Nifty Midcap Select", symbol: "MIDCPNIFTY", name: "Nifty Midcap Select" },
  INDIA_VIX: { key: "NSE_INDEX|India VIX", symbol: "INDIA VIX", name: "India VIX" }
};

const n = (v, d=0) => Number.isFinite(Number(v)) ? Number(v) : d;
const r2 = v => Math.round(n(v) * 100) / 100;
const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
const percent = (a,b) => b ? (a-b)/b*100 : 0;

function headers() {
  if (!accessToken) {
    const e = new Error("Upstox access token is not configured.");
    e.statusCode = 401; throw e;
  }
  return { Accept:"application/json", Authorization:`Bearer ${accessToken}` };
}
async function get(url, params={}) {
  try {
    const x = await axios.get(url,{headers:headers(),params,timeout:12000});
    return x.data;
  } catch(e) {
    const status=e.response?.status||500, data=e.response?.data;
    const err=new Error(status===401 ? "Upstox access token expired or invalid." : (data?.errors?.[0]?.message||data?.message||"Upstox API request failed"));
    err.statusCode=status; err.data=data; throw err;
  }
}
function pick(map,key){ return map?.[key] || Object.values(map||{}).find(x=>x?.instrument_token===key) || null; }

async function quotes(keys){
  const list=[...new Set(keys.filter(Boolean))];
  const d=await get(`${API}/v2/market-quote/quotes`,{instrument_key:list.join(",")});
  return d?.data||{};
}
async function search(q,ex){
  const d=await get(`${API}/v2/instruments/search`,{
    query:String(q).slice(0,50), exchanges:ex, segments:"EQ,INDEX",
    page_number:1, records:30
  });
  return d?.data||[];
}
async function candles(key){
  const d=await get(`${API3}/historical-candle/intraday/${encodeURIComponent(key)}/minutes/1`);
  return d?.data?.candles||[];
}
function yday(){
  const d=new Date(); d.setUTCDate(d.getUTCDate()-1);
  return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(d);
}
async function previous(key){
  const d=await get(`${API3}/historical-candle/${encodeURIComponent(key)}/days/1/${yday()}`);
  return d?.data?.candles?.[0]||null;
}

function ema(v,p){
  if(v.length<p)return null;
  let e=v.slice(0,p).reduce((a,b)=>a+b,0)/p,k=2/(p+1);
  for(let i=p;i<v.length;i++)e=v[i]*k+e*(1-k);
  return e;
}
function rsi(v,p=14){
  if(v.length<=p)return null;
  let g=0,l=0;
  for(let i=1;i<=p;i++){let d=v[i]-v[i-1];if(d>=0)g+=d;else l-=d}
  let ag=g/p,al=l/p;
  for(let i=p+1;i<v.length;i++){let d=v[i]-v[i-1];ag=(ag*(p-1)+Math.max(d,0))/p;al=(al*(p-1)+Math.max(-d,0))/p}
  return al===0?100:100-100/(1+ag/al);
}
function sma(v,p){if(v.length<p)return null;return v.slice(-p).reduce((a,b)=>a+b,0)/p}
function atr(c,p=14){
  if(c.length<p+1)return null;let t=[];
  for(let i=1;i<c.length;i++){let h=n(c[i][2]),l=n(c[i][3]),pc=n(c[i-1][4]);t.push(Math.max(h-l,Math.abs(h-pc),Math.abs(l-pc)))}
  return sma(t,p);
}
function vwap(c){
  let pv=0,vol=0;
  for(const x of c){let h=n(x[2]),l=n(x[3]),cl=n(x[4]),v=n(x[5]);pv+=((h+l+cl)/3)*v;vol+=v}
  return vol?pv/vol:null;
}
function technical(c,price){
  const close=c.map(x=>n(x[4])), e9=ema(close,9),e21=ema(close,21),rr=rsi(close),vw=vwap(c),a=atr(c),av=sma(c.map(x=>n(x[5])),20),lv=n(c.at(-1)?.[5]),vr=av?lv/av:0;
  let score=0;
  if(e9!=null&&e21!=null)score+=e9>e21?20:e9<e21?-20:0;
  if(vw!=null)score+=price>vw?15:price<vw?-15:0;
  if(rr!=null)score+=rr>=60?15:rr<=40?-15:0;
  if(vr>=1.5)score+=price>=n(c.at(-1)?.[1])?10:-10;
  score=clamp(score,-60,60);
  return {
    technicalScore:score,ema9:r2(e9),ema21:r2(e21),rsi14:r2(rr),vwap:r2(vw),atr14:r2(a),
    averageVolume:Math.round(av||0),volumeRatio:r2(vr),
    emaTrend:e9>e21?"BULLISH":e9<e21?"BEARISH":"NEUTRAL",
    vwapTrend:price>vw?"ABOVE_VWAP":price<vw?"BELOW_VWAP":"NEUTRAL",
    rsiSignal:rr>=60?"BULLISH":rr<=40?"BEARISH":"NEUTRAL",
    volumeConfirmed:vr>=1.5
  };
}
function depth(q){
  const b=Array.isArray(q?.depth?.buy)?q.depth.buy:[],s=Array.isArray(q?.depth?.sell)?q.depth.sell:[];
  const bq=b.reduce((a,x)=>a+n(x?.quantity),0),sq=s.reduce((a,x)=>a+n(x?.quantity),0),t=bq+sq;
  const bp=t?bq/t*100:50,sp=t?sq/t*100:50;
  return {buyQuantity:bq,sellQuantity:sq,totalDepth:t,buyPercent:r2(bp),sellPercent:r2(sp),
    trend:bp>=60?"BUYERS_STRONG":sp>=60?"SELLERS_STRONG":"NEUTRAL"};
}

function analyze(q,c,prev,meta){
  const price=n(q?.last_price),o=n(q?.ohlc?.open),h=n(q?.ohlc?.high),lo=n(q?.ohlc?.low),vol=n(q?.volume),oi=n(q?.oi);
  const prevClose=prev?n(prev[4]):n(q?.cp??q?.ohlc?.close),change=price-prevClose,changePct=percent(price,prevClose);
  const t=technical(c,price),md=depth(q),range=Math.max(h-lo,price*.001),pos=clamp((price-lo)/range,0,1);
  const trend=price>o&&pos>=.6?"BULLISH":price<o&&pos<=.4?"BEARISH":"SIDEWAYS";
  const atrv=t.atr14||range*.35,risk=Math.max(atrv,price*.005);
  const buyStop=price-risk,sellStop=price+risk,buyT1=price+risk*1.5,buyT2=price+risk*2,sellT1=price-risk*1.5,sellT2=price-risk*2;
  const buyRR=1.5,sellRR=1.5;
  let score=50+t.technicalScore*.55+(trend==="BULLISH"?15:trend==="BEARISH"?-15:0)+(md.trend==="BUYERS_STRONG"?15:md.trend==="SELLERS_STRONG"?-15:0);
  score=clamp(Math.round(score),0,100);
  const tb=t.technicalScore>=20,tsb=t.technicalScore>=35,tbN=t.technicalScore<=-20,tsN=t.technicalScore<=-35;
  const buy=trend==="BULLISH"&&tb&&score>=65&&buyRR>=1.5&&(md.trend==="BUYERS_STRONG"||md.totalDepth===0);
  const sBuy=trend==="BULLISH"&&tsb&&score>=75&&buyRR>=1.5&&(md.trend==="BUYERS_STRONG"||md.totalDepth===0);
  const sell=trend==="BEARISH"&&tbN&&score<=35&&sellRR>=1.5&&(md.trend==="SELLERS_STRONG"||md.totalDepth===0);
  const sSell=trend==="BEARISH"&&tsN&&score<=25&&sellRR>=1.5&&(md.trend==="SELLERS_STRONG"||md.totalDepth===0);
  const breakout=price>=h&&trend==="BULLISH"&&tb&&score>=70&&buyRR>=1.5&&(md.trend==="BUYERS_STRONG"||md.totalDepth===0);
  let signal="WAIT",reason="Trend exists, but complete technical, depth and R:R confirmation is missing.";
  if(breakout){signal="BREAKOUT BUY";reason="Resistance breakout confirmed by price, technical momentum and acceptable R:R."}
  else if(sBuy){signal="STRONG BUY";reason="Strong bullish trend with technical, depth and risk/reward confirmation."}
  else if(buy){signal="BUY";reason="Bullish trend confirmed by technical indicators and market depth."}
  else if(sSell){signal="STRONG SELL";reason="Strong bearish trend with technical, depth and risk/reward confirmation."}
  else if(sell){signal="SELL";reason="Bearish trend confirmed by technical indicators and market depth."}
  else if(trend==="SIDEWAYS"){signal="AVOID";reason="No clear directional trading setup."}
  const isSell=signal.includes("SELL"),active=!["WAIT","AVOID"].includes(signal),rr=1.5;
  return {
    ...meta,price:r2(price),prevClose:r2(prevClose),netChange:r2(change),changePercent:r2(changePct),
    open:r2(o),high:r2(h),low:r2(lo),close:r2(n(q?.ohlc?.close)),volume,oi,
    avgTradePrice:r2(q?.average_price||q?.avg_price),trend,aiScore:score,confidence:signal==="WAIT"||signal==="AVOID"?Math.min(70,Math.max(50,score)):Math.min(95,Math.max(50,score)),
    signal,reason,entry:r2(price),target1:r2(isSell?sellT1:buyT1),target2:r2(isSell?sellT2:buyT2),stopLoss:r2(isSell?sellStop:buyStop),
    support:r2(lo),resistance:r2(h),riskReward:rr,tradeQuality:"GOOD",
    technicalConfirmation:{...t,buyersConfirmed:md.trend==="BUYERS_STRONG",sellersConfirmed:md.trend==="SELLERS_STRONG",
      confirmationStatus:signal.includes("BUY")?"BUY CONFIRMED":signal.includes("SELL")?"SELL CONFIRMED":"WAITING FOR CONFIRMATION"},
    marketDepth:md,riskRewardTarget1:rr,riskRewardTarget2:2,
    previousDay:prev?{date:prev[0],open:n(prev[1]),high:n(prev[2]),low:n(prev[3]),close:n(prev[4]),volume:n(prev[5])}:null
  };
}

app.get("/api/health",(req,res)=>res.json({success:true,app:"Dharmrajsinh Live Market",version:"V7.4"}));

app.get("/api/status",(req,res)=>{
  const d=new Date(),fmt=new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",dateStyle:"medium",timeStyle:"medium"});
  const wd=new Intl.DateTimeFormat("en-US",{timeZone:"Asia/Kolkata",weekday:"short"}).format(d);
  const hm=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",hour:"2-digit",minute:"2-digit",hour12:false}).format(d).split(":").map(Number);
  const m=hm[0]*60+hm[1],open=m>=555&&m<930&&!["Sat","Sun"].includes(wd);
  res.json({market:open?"MARKET_OPEN":"MARKET_CLOSED",date:fmt.format(d).split(",")[0],time:fmt.format(d).split(",").slice(1).join(",").trim()});
});

app.get("/api/search",async(req,res)=>{
  try{
    const q=String(req.query.q||"").trim(),ex=["NSE","BSE"].includes(String(req.query.exchange||"").toUpperCase())?String(req.query.exchange).toUpperCase():"ALL";
    if(!q)return res.status(400).json({success:false,message:"Search query required."});
    const rows=await search(q,ex);
    res.json({success:true,results:rows.map(x=>({instrument:x.instrument_key,symbol:x.trading_symbol||x.short_name||x.name,name:x.name||x.short_name||x.trading_symbol,exchange:x.exchange||"",segment:x.segment||"",isin:x.isin||""}))});
  }catch(e){res.status(e.statusCode||500).json({success:false,message:e.message,error:e.data})}
});

app.get("/api/live",async(req,res)=>{
  try{
    const instrument=String(req.query.instrument||"").trim(),symbol=String(req.query.symbol||""),name=String(req.query.name||symbol);
    if(!instrument)return res.status(400).json({success:false,message:"Instrument key is required."});
    const [qm,c]=await Promise.all([quotes([instrument]),candles(instrument)]);
    const q=pick(qm,instrument); if(!q)return res.status(404).json({success:false,message:"Quote not found."});
    let p=null;try{p=await previous(instrument)}catch(_){}
    res.json({success:true,instrument,data:analyze(q,c,p,{symbol,name,instrument,candles:c.length})});
  }catch(e){res.status(e.statusCode||500).json({success:false,message:e.message,error:e.data})}
});

app.get("/api/market-overview",async(req,res)=>{
  try{
    const keys=Object.values(INDEXES).map(x=>x.key),qm=await quotes(keys),out={};
    for(const [id,m] of Object.entries(INDEXES)){
      const q=pick(qm,m.key);
      if(!q){out[id]={...m,unavailable:true};continue}
      const p=n(q.last_price),cp=n(q.cp??q.ohlc?.close);
      out[id]={...m,price:r2(p),prevClose:r2(cp),netChange:r2(p-cp),changePercent:r2(percent(p,cp)),unavailable:false};
    }
    res.json({success:true,data:out});
  }catch(e){res.status(e.statusCode||500).json({success:false,message:e.message,error:e.data})}
});

app.get("/auth/upstox",(req,res)=>{
  if(!process.env.UPSTOX_CLIENT_ID||!process.env.UPSTOX_REDIRECT_URI)return res.status(500).send("Set UPSTOX_CLIENT_ID and UPSTOX_REDIRECT_URI.");
  const u=new URL(`${API}/v2/login/authorization/dialog`);
  u.searchParams.set("response_type","code");u.searchParams.set("client_id",process.env.UPSTOX_CLIENT_ID);u.searchParams.set("redirect_uri",process.env.UPSTOX_REDIRECT_URI);
  res.redirect(u.toString());
});

app.get("/auth/callback",async(req,res)=>{
  try{
    const body=new URLSearchParams({code:String(req.query.code||""),client_id:process.env.UPSTOX_CLIENT_ID||"",client_secret:process.env.UPSTOX_CLIENT_SECRET||"",redirect_uri:process.env.UPSTOX_REDIRECT_URI||"",grant_type:"authorization_code"});
    const x=await axios.post(`${API}/v2/login/authorization/token`,body.toString(),{headers:{Accept:"application/json","Content-Type":"application/x-www-form-urlencoded"}});
    accessToken=x.data?.access_token||"";
    res.send(`<h2>Dharmrajsinh Live Market</h2><p>Upstox connected. <a href="/">Open dashboard</a></p>`);
  }catch(e){res.status(e.response?.status||500).send(`Upstox login failed: ${e.response?.data?.message||e.message}`)}
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,"0.0.0.0",()=>console.log(`Dharmrajsinh Live Market V7.4 on ${PORT}`));
