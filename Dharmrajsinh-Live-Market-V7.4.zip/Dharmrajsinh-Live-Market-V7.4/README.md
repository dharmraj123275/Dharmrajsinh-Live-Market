# Dharmrajsinh Live Market V7.4

Complete mobile-first Node/Express project for NSE + BSE live stock analysis using Upstox.

### Features
- NSE + BSE equity search
- Live stock quote refresh
- NIFTY 50, SENSEX, MIDCPNIFTY, INDIA VIX cards
- Previous-day OHLC
- ATP when supplied by Upstox
- Market depth
- EMA 9/21, RSI 14, VWAP, ATR 14, volume ratio
- BUY / STRONG BUY / BREAKOUT BUY / WAIT / SELL / STRONG SELL / AVOID
- Entry, targets, stop-loss, support/resistance, R:R
- Upstox OAuth route
- Render-ready

### Setup
1. `npm install`
2. Copy `.env.example` to `.env`
3. Add your Upstox credentials/token
4. `npm start`

### Render
Build: `npm install`
Start: `npm start`

Set the same environment variables in Render. Never commit your secret or access token to GitHub.

Fundamentals/news are intentionally not fabricated; add a licensed/free provider later if required.
